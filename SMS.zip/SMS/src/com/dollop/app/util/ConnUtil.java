package com.dollop.app.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnUtil {
	private static final String DB_NAME="mydb1";
	private static final String DB_URL="jdbc:mysql://localhost:3306/"+DB_NAME;
	private static final String DB_UNAME="root";
	private static final String DB_PWD="";
	private static Connection con=null;
	public static Connection getConnection() {
		if(con==null)
			return getConnection(DB_URL,DB_UNAME,DB_PWD);
		return con;
	}
	private static Connection getConnection(String dbUrl, String dbUname, String dbPwd) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(dbUrl, dbUname, dbPwd);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
