package com.dollop.app;

import java.util.List;

import com.dollop.app.bean.Student;
import com.dollop.app.dao.IStudentDao;
import com.dollop.app.dao.impl.StudentDaoImpl;

public class StudentMain {
	public static void main(String[] args) {
		Student student1 = new Student(103,"kamal Narayan");
		Student student2 = new Student("omprakash");
		IStudentDao ist = new StudentDaoImpl();
		/*
		 * if (ist.save(student1)) System.out.println("saved1"); if (ist.save(student2))
		 * System.out.println("saved2");
		 */
		  List<Student> students=ist.getList();
		  for (Student student3 : students) {
		  System.out.println(student3); 
		  } 
		  System.out.println(ist.getById(105));
		  System.out.println(ist.deleteById(104));
		  students=ist.getList();
		  for (Student student3 : students) {
		  System.out.println(student3); 
		  } 
		 
	}

}
