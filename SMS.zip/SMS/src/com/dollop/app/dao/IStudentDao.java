package com.dollop.app.dao;

import java.util.List;

import com.dollop.app.bean.Student;

public interface IStudentDao {
	public Boolean save(Student student);
	public Student getById(Integer sid);
	public List<Student> getList();
	public Boolean deleteById(Integer sid);
	
}
