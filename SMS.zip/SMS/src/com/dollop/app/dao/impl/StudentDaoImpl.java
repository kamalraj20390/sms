package com.dollop.app.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dollop.app.bean.Student;
import com.dollop.app.dao.IStudentDao;
import com.dollop.app.util.ConnUtil;

public class StudentDaoImpl implements IStudentDao {
	private Connection con=null;
	private Statement stmt=null;
	public StudentDaoImpl() {
		super();
		this.con=ConnUtil.getConnection();
	}

	List<Student> students=new ArrayList<>();
	@Override
	public Boolean save(Student student) {
		Integer rows=null;
		String studentSave=null;
		if(student.getSid()==null)
		studentSave="INSERT INTO STUDENT VALUES("
				+student.getSid()+",'"+student.getsName()+"')";
		else
			studentSave="UPDATE student SET sname='"
		+student.getsName()+"' WHERE sid="+student.getSid();
		try {
			stmt=con.createStatement();
			rows=stmt.executeUpdate(studentSave);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rows>0;
	}

	@Override
	public Student getById(Integer sid) {
		Student student=null;
		String studentById="select * from student where sid="+sid;
		try {
			stmt=con.createStatement();
			ResultSet rs = stmt.executeQuery(studentById);
			while (rs.next()) {
				student=new Student();
				student.setSid(rs.getInt("sid"));
				student.setsName(rs.getString("sname"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return student;
	}

	@Override
	public List<Student> getList() {
		String StudentList="select * from student";
		try {
			stmt=con.createStatement();
			ResultSet rs = stmt.executeQuery(StudentList);
			while (rs.next()) {
				Student student=new Student();
				student.setSid(rs.getInt("sid"));
				student.setsName(rs.getString("sname"));
				students.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return students;
	}

	@Override
	public Boolean deleteById(Integer sid) {
		String deleteStudent="DELETE FROM student WHERE sid="+sid;
		Integer rows=null;
		try {
			stmt=con.createStatement();
			rows=stmt.executeUpdate(deleteStudent);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rows>0;
	}

}
