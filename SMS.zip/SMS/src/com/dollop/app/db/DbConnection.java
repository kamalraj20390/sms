package com.dollop.app.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DbConnection {
	private static final String DB_NAME="mydb1";
	private static final String DB_URL="jdbc:mysql://localhost:3306/"+DB_NAME;
	private static final String DB_UNAME="root";
	private static final String DB_PWD="";
	private static final String CREATE_SQL="CREATE TABLE BOOKS("
			+ "BOOK_ID INT(10),"
			+ "BOOK_NAME VARCHAR(100),"
			+ "BOOK_PRICE INT(10))";
	private static final String SELECT_SQL="SELECT * FROM BOOKS";
	public static void main(String[] args) {
		Integer bid = null,bprice = null;
		String bname = null;
		
		//step-1 Load Driver Class
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		//step-2 Get Db Connection
			Connection con = DriverManager.getConnection(DB_URL, DB_UNAME, DB_PWD);
			System.out.println(con.getClass().getName());
			//step-3 Create Statement
			Statement stmt = con.createStatement();
		//step-4 Execute Query
			//boolean execute = stmt.execute(CREATE_SQL);
			//System.out.println("return"+execute);
			/*Scanner sc=new Scanner(System.in);
			while(true) {
			bid=sc.nextInt();
			sc.nextLine();
			bname=sc.nextLine();	
			bprice=sc.nextInt();	
			String INSERT_SQL="INSERT INTO BOOKS VALUES("+bid+",'"+bname+"',"+bprice+")";
			int rows = stmt.executeUpdate(INSERT_SQL);
			System.out.println("Inserted Rows "+rows);
			}*/
			ResultSet rs = stmt.executeQuery(SELECT_SQL);
			while (rs.next()) {
				System.out.println("bid="+rs.getInt("book_id")+
						" bname "+rs.getString("book_name")+
						" bprice "+rs.getInt("book_price"));
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
